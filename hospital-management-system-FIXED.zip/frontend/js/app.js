/**
 * Hospital Management System - Main Application File
 * Handles page routing, navigation, and overall app state
 */

class HospitalApp {
    constructor() {
        this.currentPage = 'login';
        this.currentUser = null;
        this.apiUrl = 'http://localhost:5000/api';
        this.init();
    }
    
    init() {
        console.log('Initializing Hospital Management System...');
        this.setupEventListeners();
        this.checkAuthentication();
    }
    
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => this.handleNavigation(e));
        });
        
        // Logout
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.logout());
        }
        
        // Menu toggle for mobile
        const menuToggle = document.getElementById('menu-toggle');
        if (menuToggle) {
            menuToggle.addEventListener('click', () => this.toggleSidebar());
        }
        
        // Modal close
        const modalClose = document.querySelector('.modal-close');
        if (modalClose) {
            modalClose.addEventListener('click', () => this.closeModal());
        }
        
        // Login form
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
    }
    
    async checkAuthentication() {
        const token = localStorage.getItem('authToken');
        
        if (!token) {
            this.showPage('login');
            return;
        }
        
        try {
            const response = await fetch(`${this.apiUrl}/auth/me`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (response.ok) {
                this.currentUser = await response.json();
                this.showPage('dashboard');
                this.updateUserInfo();
            } else {
                localStorage.removeItem('authToken');
                this.showPage('login');
            }
        } catch (error) {
            console.error('Auth check failed:', error);
            this.showPage('login');
        }
    }
    
    async handleLogin(e) {
        e.preventDefault();
        
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        
        try {
            const response = await fetch(`${this.apiUrl}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });
            
            if (response.ok) {
                const data = await response.json();
                localStorage.setItem('authToken', data.token);
                this.currentUser = data.user;
                this.showPage('dashboard');
                this.updateUserInfo();
                this.showToast('Login successful!', 'success');
            } else {
                const error = await response.json();
                this.showToast(error.error || 'Login failed', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showToast('Login failed. Please try again.', 'error');
        }
    }
    
    async logout() {
        try {
            const token = localStorage.getItem('authToken');
            await fetch(`${this.apiUrl}/auth/logout`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
        } catch (error) {
            console.error('Logout error:', error);
        }
        
        localStorage.removeItem('authToken');
        this.currentUser = null;
        this.showPage('login');
        this.showToast('Logged out successfully', 'info');
    }
    
    handleNavigation(e) {
        e.preventDefault();
        const page = e.currentTarget.dataset.page;
        this.showPage(page);
    }
    
    showPage(page) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(p => {
            p.classList.add('hidden');
        });
        
        // Hide all content sections
        document.querySelectorAll('.content-section').forEach(s => {
            s.classList.add('hidden');
        });
        
        // Remove active state from nav items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        
        if (page === 'login') {
            document.getElementById('login-page').classList.remove('hidden');
            this.currentPage = 'login';
        } else {
            document.getElementById('dashboard-page').classList.remove('hidden');
            document.getElementById(`${page}-content`).classList.remove('hidden');
            
            // Set active nav item
            document.querySelector(`[data-page="${page}"]`).classList.add('active');
            
            // Update page title
            document.getElementById('page-title').textContent = this.formatPageTitle(page);
            
            this.currentPage = page;
            
            // Load page data
            this.loadPageData(page);
        }
        
        // Close sidebar on mobile
        this.closeSidebar();
    }
    
    formatPageTitle(page) {
        const titles = {
            dashboard: 'Dashboard',
            patients: 'Patients',
            doctors: 'Doctors',
            appointments: 'Appointments',
            records: 'Medical Records',
            billing: 'Billing & Invoices'
        };
        return titles[page] || page.charAt(0).toUpperCase() + page.slice(1);
    }
    
    loadPageData(page) {
        // Dispatch page-specific loading
        const event = new CustomEvent('pageLoad', { detail: { page } });
        document.dispatchEvent(event);
    }
    
    updateUserInfo() {
        if (this.currentUser) {
            document.getElementById('user-name').textContent = this.currentUser.fullName || this.currentUser.email;
            document.getElementById('user-role').textContent = this.currentUser.role.toUpperCase();
        }
    }
    
    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('open');
    }
    
    closeSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.remove('open');
    }
    
    showModal(title, content) {
        const modal = document.getElementById('modal');
        const modalTitle = document.getElementById('modal-title');
        const modalBody = document.getElementById('modal-body');
        
        modalTitle.textContent = title;
        modalBody.innerHTML = content;
        modal.classList.remove('hidden');
    }
    
    closeModal() {
        const modal = document.getElementById('modal');
        modal.classList.add('hidden');
    }
    
    showToast(message, type = 'info') {
        const toast = document.getElementById('toast');
        toast.textContent = message;
        toast.className = `toast ${type}`;
        toast.classList.remove('hidden');
        
        setTimeout(() => {
            toast.classList.add('hidden');
        }, 3000);
    }
    
    getAuthToken() {
        return localStorage.getItem('authToken');
    }
    
    isAuthenticated() {
        return !!this.getAuthToken();
    }
    
    canAccess(requiredRole) {
        if (!this.currentUser) return false;
        if (this.currentUser.role === 'admin') return true;
        return this.currentUser.role === requiredRole;
    }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.app = new HospitalApp();
});
