/**
 * Dashboard Page Module
 * Displays key statistics and recent activity
 */

class DashboardPage {
    constructor() {
        this.init();
    }
    
    init() {
        document.addEventListener('pageLoad', (e) => {
            if (e.detail.page === 'dashboard') {
                this.loadDashboardData();
            }
        });
    }
    
    async loadDashboardData() {
        try {
            // Load statistics
            const stats = await window.api.getDashboardStats();
            this.displayStats(stats);
            
            // Load recent activity
            const activity = await window.api.getRecentActivity(10);
            this.displayActivity(activity);
        } catch (error) {
            console.error('Failed to load dashboard data:', error);
            window.app.showToast('Failed to load dashboard data', 'error');
        }
    }
    
    displayStats(stats) {
        document.getElementById('stat-patients').textContent = stats.totalPatients || 0;
        document.getElementById('stat-appointments').textContent = stats.todayAppointments || 0;
        document.getElementById('stat-bills').textContent = stats.pendingBills || 0;
        document.getElementById('stat-doctors').textContent = stats.availableDoctors || 0;
    }
    
    displayActivity(activity) {
        const activityList = document.getElementById('activity-list');
        
        if (!activity || activity.length === 0) {
            activityList.innerHTML = '<div class="no-data"><p>No recent activity</p></div>';
            return;
        }
        
        activityList.innerHTML = activity.map(item => `
            <div class="activity-item">
                <div class="activity-type">${this.getActivityIcon(item.type)}</div>
                <div class="activity-details">
                    <div class="activity-description">${item.description}</div>
                    <div class="activity-time">${this.formatDate(item.date)}</div>
                </div>
            </div>
        `).join('');
    }
    
    getActivityIcon(type) {
        const icons = {
            'appointment': '📅',
            'record': '📋',
            'invoice': '💳'
        };
        return icons[type] || '📌';
    }
    
    formatDate(date) {
        const d = new Date(date);
        const now = new Date();
        const diff = now - d;
        
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);
        
        if (minutes < 60) return `${minutes} minutes ago`;
        if (hours < 24) return `${hours} hours ago`;
        if (days < 7) return `${days} days ago`;
        
        return d.toLocaleDateString();
    }
}

// Initialize dashboard page
document.addEventListener('DOMContentLoaded', () => {
    window.dashboardPage = new DashboardPage();
});
